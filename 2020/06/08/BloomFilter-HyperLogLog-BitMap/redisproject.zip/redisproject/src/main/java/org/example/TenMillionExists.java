package org.example;

import io.rebloom.client.Client;

public class TenMillionExists {
    public static void main( String[] args ) {

        Client client = new Client(Constants.HOST,Constants.PORT);

        client.delete("guahao");
        for (int i = 0; i < 10; i++) {
            client.add("guahao", "user" + i);
            boolean ret = client.exists("guahao", "user" + i);
            if (!ret) {//如果误判会输出
                System.out.println(i);
                break;
            }
        }

        client.close();
    }
}
