package org.rico.groupchatmsg.protocol.request;

import lombok.Data;
import org.rico.groupchatmsg.protocol.Packet;

import static org.rico.groupchatmsg.protocol.command.Command.QUIT_GROUP_REQUEST;

@Data
public class QuitGroupRequestPacket extends Packet {

    private String groupId;

    @Override
    public Byte getCommand() {

        return QUIT_GROUP_REQUEST;
    }
}
