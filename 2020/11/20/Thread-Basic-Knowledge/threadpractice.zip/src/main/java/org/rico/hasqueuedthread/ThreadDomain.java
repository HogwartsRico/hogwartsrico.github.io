package org.rico.hasqueuedthread;

import java.util.concurrent.locks.ReentrantLock;

public class ThreadDomain extends ReentrantLock {
    public void waitMethod() {
        try {
            lock();
            Thread.sleep(Integer.MAX_VALUE);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            unlock();
        }
    }
}
