package org.rico.reentrantreadwritelockdemo;

public class Test {
    public static void main(String[] args) {

    ReadService service = new ReadService();
    Thread a = new Thread(service::read);
        a.setName("A");

    Thread b = new Thread(service::read);
        b.setName("B");

        a.start();
        b.start();
    }
}
