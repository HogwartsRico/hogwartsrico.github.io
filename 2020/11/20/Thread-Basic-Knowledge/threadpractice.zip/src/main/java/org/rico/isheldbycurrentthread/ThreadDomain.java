package org.rico.isheldbycurrentthread;

import java.util.concurrent.locks.ReentrantLock;

public class ThreadDomain {
    private ReentrantLock lock = new ReentrantLock();
    public void testMethod() {
        try {
            lock.lock();
            System.out.println(Thread.currentThread().getName() + "线程持有了锁！");
            System.out.println(Thread.currentThread().getName() + "线程是否持有锁？" + lock.isHeldByCurrentThread());
            System.out.println("是否有任意线程持有了锁？" + lock.isLocked());
            Thread.sleep(Integer.MAX_VALUE);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public void testHoldLock() {
        System.out.println("当前线程"+Thread.currentThread().getName()+"是否持有锁？" + lock.isHeldByCurrentThread());
        System.out.println("是否有任意线程持有了锁？" + lock.isLocked());
    }
}
