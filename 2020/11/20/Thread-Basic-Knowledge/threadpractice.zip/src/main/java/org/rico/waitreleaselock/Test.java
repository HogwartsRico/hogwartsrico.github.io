package org.rico.waitreleaselock;

public class Test {

    public static void main(String[] args) {
        Object lock = new Object();
        MyThread t1 = new MyThread(lock);
        MyThread t2 = new MyThread(lock);
        t1.start();
        t2.start();
    }
}
