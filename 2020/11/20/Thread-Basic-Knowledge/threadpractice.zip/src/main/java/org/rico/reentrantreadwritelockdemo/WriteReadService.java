package org.rico.reentrantreadwritelockdemo;

import java.util.concurrent.locks.ReentrantReadWriteLock;

public class WriteReadService {
    private ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    public void read(){
            try {
                lock.readLock().lock();
                System.out.println("获得读锁" + Thread.currentThread().getName() + " " + System.currentTimeMillis());
                //Thread.sleep(1000 * 10);
            } finally {
                lock.readLock().unlock();
            }

    }

    public void write(){
            try{
                lock.writeLock().lock();
                System.out.println("获得写锁" + Thread.currentThread().getName() + " " + System.currentTimeMillis());
                //Thread.sleep(1000 * 10);
            }finally {
                lock.writeLock().unlock();
            }
    }
}
