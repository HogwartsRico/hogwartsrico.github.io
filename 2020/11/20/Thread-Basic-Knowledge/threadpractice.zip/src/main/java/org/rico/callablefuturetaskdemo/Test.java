package org.rico.callablefuturetaskdemo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
public class Test {
    public static void main(String[] args) throws Exception {
        ExecutorService executorService = Executors.newCachedThreadPool();
        CallableThread ct = new CallableThread();
        FutureTask<String> f = new FutureTask<String>(ct);
        executorService.submit(f);
        executorService.shutdown();
        System.out.println("当前时间为" + System.currentTimeMillis());
        String str = f.get();
        System.out.println("Future已拿到数据, str = " + str + ", 当前时间为" + System.currentTimeMillis());
    }
}
