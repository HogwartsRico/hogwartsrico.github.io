package org.rico.groupchatmsg.protocol.response;

import lombok.Data;
import org.rico.groupchatmsg.protocol.Packet;
import org.rico.groupchatmsg.session.Session;

import java.util.List;

import static org.rico.groupchatmsg.protocol.command.Command.LIST_GROUP_MEMBERS_RESPONSE;

@Data
public class ListGroupMembersResponsePacket extends Packet {

    private String groupId;

    private List<Session> sessionList;

    @Override
    public Byte getCommand() {

        return LIST_GROUP_MEMBERS_RESPONSE;
    }
}
