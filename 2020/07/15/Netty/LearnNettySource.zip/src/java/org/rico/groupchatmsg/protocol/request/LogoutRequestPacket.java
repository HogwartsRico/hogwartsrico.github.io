package org.rico.groupchatmsg.protocol.request;

import lombok.Data;
import org.rico.groupchatmsg.protocol.Packet;

import static org.rico.groupchatmsg.protocol.command.Command.LOGOUT_REQUEST;

@Data
public class LogoutRequestPacket extends Packet {
    @Override
    public Byte getCommand() {

        return LOGOUT_REQUEST;
    }
}
