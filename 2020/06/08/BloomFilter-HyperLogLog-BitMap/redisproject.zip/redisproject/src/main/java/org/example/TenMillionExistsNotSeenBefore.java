package org.example;

import com.google.common.hash.BloomFilter;
import io.rebloom.client.Client;

public class TenMillionExistsNotSeenBefore {
    public static void main( String[] args ) {

        Client client = new Client(Constants.HOST,Constants.PORT);

        client.delete("guahao");
        for (int i = 0; i < 10; i++) {
            client.add("guahao", "user" + i);
            boolean ret = client.exists("guahao", "user" + i);
            if (!ret) {//如果误判会输出
                System.out.println(i);
                break;
            }
        }

        client.close();
    }
}
