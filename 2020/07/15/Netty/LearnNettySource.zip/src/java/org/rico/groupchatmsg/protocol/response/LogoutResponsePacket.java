package org.rico.groupchatmsg.protocol.response;

import lombok.Data;
import org.rico.groupchatmsg.protocol.Packet;

import static org.rico.groupchatmsg.protocol.command.Command.LOGOUT_RESPONSE;

@Data
public class LogoutResponsePacket extends Packet {

    private boolean success;

    private String reason;


    @Override
    public Byte getCommand() {

        return LOGOUT_RESPONSE;
    }
}
