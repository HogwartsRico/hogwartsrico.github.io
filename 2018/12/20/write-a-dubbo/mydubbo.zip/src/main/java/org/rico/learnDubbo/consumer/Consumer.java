package org.rico.learnDubbo.consumer;
import org.rico.learnDubbo.framework.ProxyFactory;
import org.rico.learnDubbo.provider.api.HelloService;
/**
 * Created by chenhongjie on 2018/12/21.
 */
public class Consumer {
    public static void main(String[] args) {

        HelloService helloService =  ProxyFactory.getProxy(HelloService.class);//如果用了Spring的话这一步就交给Spring容器去做了,因为Dubbo和Spring是可以结合的
        String result = helloService.sayHello("陈宏杰  哈哈");
        System.out.println(result);














        /*
        HttpClient httpClient=new HttpClient();
        TransferModel transferModel=new TransferModel(HelloService.class.getName(),"sayHello",new Object[]{"rico"},new Class[]{String.class});//第一个参数:调用哪个接口 第二个参数:调用接口的哪个方法,第三个参数:参数组成的数组,第四个参数,参数类型数组
        String result=httpClient.post("localhost",8080,transferModel);
        System.out.println(result);

        上面这样可以运行，但是还是和Dubbo那样的直接通过调用方法就得到结果的形式差一点
        应该是形如下面这样的
        DemoService demoService(DemoService)context.getBean("demoService");
        String hello=demoService.sayHello("rico);
        这就需要用到动态代理了
        */
    }
}
