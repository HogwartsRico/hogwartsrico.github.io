package org.rico.priority;

public class Test {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            MyThread1 t1 = new MyThread1();
            t1.setPriority(6);
            t1.start();
            MyThread2 t2 = new MyThread2();
            t2.setPriority(4);
            t2.start();
        }
    }
}
