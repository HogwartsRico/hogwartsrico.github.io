# RocketMQ PHP SDK

This is PHP SDK for RocketMQ. Written with pure PHP language.