package org.rico.consumerproduce;

public class ValueObject {
    public static String value = "";
}
