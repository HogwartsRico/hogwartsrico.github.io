package org.rico.creategroupchat.attribute;

import io.netty.util.AttributeKey;
import org.rico.creategroupchat.session.Session;

public interface Attributes {
    AttributeKey<Session> SESSION = AttributeKey.newInstance("session");
}
