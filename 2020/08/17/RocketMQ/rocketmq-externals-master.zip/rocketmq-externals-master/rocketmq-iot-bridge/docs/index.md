# MQTT Bridge for Apache RocketMQ Documents
- [architecture](architecture.md)
- [RIP](https://docs.google.com/document/d/1G1-aJ74ZTjy_rxtJU3jm_YoICexNTdUVSR9E78K9xlo/edit?usp=sharing)
