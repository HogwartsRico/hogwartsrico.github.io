package org.rico.learnDubbo.register;
import org.rico.learnDubbo.framework.URL;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
/**
 * 自己实现的一个注册中心,采用map
 * Created by chenhongjie on 2018/12/20.
 */
public class RegisterServer {
    private static Map<String,Map<URL,Class>>   REGISTER =new HashMap<String,Map<URL,Class>>();//一个接口可能有多个provider的实现类
    //注册服务
    public static  void register(URL url,String interfaceName,Class implClass){//需要传入URL，服务名，接口名(interface),实现类
        Map<URL,Class> map=new HashMap<URL,Class>();//url作为key,实现的class作为value
        map.put(url,implClass);
        System.out.println("服务注册成功!注册的服务接口名为:"+interfaceName+",所在接口类为:"+implClass.getName());
        REGISTER.put(interfaceName,map);///interfaceName作为key,map作为value
        saveFile();//将map保存到文件中去
    }

    public static Class get(URL url,String interfaceName){
        REGISTER=getFile();
        return REGISTER.get(interfaceName).get(url);
    }
    //获取可用服务 如果有多个服务都实现这个方法，那就涉及到了负载均衡，看你取哪台集群了,有hsh,robin 这里采取随机的方式
    public static  URL random(String interfaceName){//这个REGISTER的map是provide在运行的时候进行注册的，而Consumer要拿的话是拿不到的，因为是2个不同的应用程序,所以要保存在文件上
        REGISTER=getFile();
        return REGISTER.get(interfaceName).keySet().iterator().next();
    }

    //将对象保存到文件中
    private  static void saveFile(){
        try {
            FileOutputStream fileOutputStream=new FileOutputStream("C:\\Users\\weiyi\\Desktop\\register.txt");
            ObjectOutputStream objectOutputStream=new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(REGISTER);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //将对象从文件中取出来
    private  static Map<String,Map<URL,Class>>  getFile(){
        try {
            FileInputStream fileInputStream=new FileInputStream("C:\\Users\\weiyi\\Desktop\\register.txt");
            ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
            return (Map<String,Map<URL,Class>>) objectInputStream.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
}
