package org.rico;

public class InterruptedDemo1 implements Runnable{
    public static void main(String[] args) throws InterruptedException {
        Thread testThread = new Thread(new InterruptedDemo1(),"InterruptionInJava");
        testThread.start();
        testThread.interrupt();
        System.out.println("主线程结束");
    }
    @Override
    public void run() {
        while(true){
            if(Thread.currentThread().isInterrupted()){
                System.out.println("我被打断了，但我仍然在运行");
                System.out.println("当前是否中断:"+Thread.interrupted());
                System.out.println("当前是否中断:"+Thread.interrupted());
            }else{
                System.out.println("还没被打断");
                return;
            }
        }
    }
}
