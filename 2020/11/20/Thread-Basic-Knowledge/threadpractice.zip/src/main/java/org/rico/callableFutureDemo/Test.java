package org.rico.callableFutureDemo;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        ExecutorService executorService = Executors.newCachedThreadPool();
        CallableThread callableThread = new CallableThread();
        Future<String> future = executorService.submit(callableThread);
        executorService.shutdown();
        //Thread.sleep(5000);
        //System.out.println("主线程等待5秒, 当前时间为" + System.currentTimeMillis());
        String str = null;
        try {
            System.out.println("获取数据");
            str = future.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        System.out.println("Future已拿到数据, str = " + str + ", 当前时间为" + System.currentTimeMillis());
    }
}
