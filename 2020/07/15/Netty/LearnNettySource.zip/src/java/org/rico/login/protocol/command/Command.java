package org.rico.login.protocol.command;

public interface Command {

    Byte LOGIN_REQUEST = 1;//登录请求

    Byte LOGIN_RESPONSE = 2;//登录响应

    Byte MESSAGE_REQUEST = 3;//消息发送

    Byte MESSAGE_RESPONSE = 4;//消息响应
}
