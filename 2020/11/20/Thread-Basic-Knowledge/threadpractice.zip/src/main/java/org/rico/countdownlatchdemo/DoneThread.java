package org.rico.countdownlatchdemo;

import java.util.concurrent.CountDownLatch;

public class DoneThread extends Thread{
    private CountDownLatch countDownLatch;

    public DoneThread(String name, CountDownLatch cdl) {
        super(name);
        this.countDownLatch = cdl;
    }

    public void run() {
        try {
            System.out.println(this.getName() + "要等待了, 时间为" + System.currentTimeMillis());
            countDownLatch.await();
            System.out.println(this.getName() + "等待完了, 时间为" + System.currentTimeMillis());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
