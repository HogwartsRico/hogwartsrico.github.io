package org.rico.countdownlatchdemo;

import java.util.concurrent.CountDownLatch;

public class Test {
    public static void main(String[] args) {
        CountDownLatch countDownLatch = new CountDownLatch(3);

        DoneThread dt0 = new DoneThread("DoneThread1", countDownLatch);
        DoneThread dt1 = new DoneThread("DoneThread2", countDownLatch);
        dt0.start();
        dt1.start();
        WorkThread wt0 = new WorkThread("WorkThread1", countDownLatch, 2);
        WorkThread wt1 = new WorkThread("WorkThread2", countDownLatch, 3);
        WorkThread wt2 = new WorkThread("WorkThread3", countDownLatch, 4);
        wt0.start();
        wt1.start();
        wt2.start();
    }
}
