package org.rico.notifynotreleaselock;

public class ThreadDomain {
    public void testMethod(Object lock) {
        try {
            synchronized (lock) {
                System.out.println("开始wait, ThreadName = " + Thread.currentThread().getName());
                lock.wait();
                System.out.println("结束wait, ThreadName = " + Thread.currentThread().getName());
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void synNotifyMethod(Object lock) {
        try {
            synchronized (lock) {
                System.out.println("开始notify,并睡五秒, ThreadName = " + Thread.currentThread().getName());
                lock.notify();
                Thread.sleep(5000);
                System.out.println("结束notify, ThreadName = " + Thread.currentThread().getName());
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
