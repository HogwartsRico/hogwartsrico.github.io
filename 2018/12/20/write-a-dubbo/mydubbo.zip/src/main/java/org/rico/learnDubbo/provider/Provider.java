package org.rico.learnDubbo.provider;
import org.rico.learnDubbo.framework.URL;
import org.rico.learnDubbo.protocol.http.HttpServer;
import org.rico.learnDubbo.provider.api.HelloService;
import org.rico.learnDubbo.provider.impl.HelloServiceImpl;
import org.rico.learnDubbo.register.RegisterServer;
/**
 * Created by chenhongjie on 2018/12/21.
 */
public class Provider {
    public static void main(String[] args) {
        //1 注册服务到map中
        URL url=new URL("localhost",8080);
        RegisterServer.register(url, HelloService.class.getName(),HelloServiceImpl.class);
        //2 启动tomcat服务
        HttpServer httpServer = new HttpServer();//这里面有一个tomcat,tomcat里有个servlet,就是DispatcherServlet,它使用HttpServerHandler来处理请求
        httpServer.start(url.getHostname(), url.getPort());
    }
}
