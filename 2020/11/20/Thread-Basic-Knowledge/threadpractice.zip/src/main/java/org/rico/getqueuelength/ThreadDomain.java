package org.rico.getqueuelength;

import java.util.concurrent.locks.ReentrantLock;

public class ThreadDomain {
    public ReentrantLock lock = new ReentrantLock();
    public void testMethod() {
        try {
            lock.lock();
            System.out.println("ThreadName = " + Thread.currentThread().getName() + "进入方法！");
            System.out.println("是否公平锁？" + lock.isFair());
            System.out.println("有"+lock.getQueueLength()+"个线程正在等待");
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }
}
