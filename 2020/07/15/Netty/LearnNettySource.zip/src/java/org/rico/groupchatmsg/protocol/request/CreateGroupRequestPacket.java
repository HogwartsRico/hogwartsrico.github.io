package org.rico.groupchatmsg.protocol.request;

import lombok.Data;
import org.rico.groupchatmsg.protocol.Packet;

import java.util.List;

import static org.rico.groupchatmsg.protocol.command.Command.CREATE_GROUP_REQUEST;

@Data
public class CreateGroupRequestPacket extends Packet {

    private List<String> userIdList;

    @Override
    public Byte getCommand() {

        return CREATE_GROUP_REQUEST;
    }
}
