package org.rico.learnDubbo.framework;

import java.io.Serializable;
import java.util.Objects;

/**
 * Created by chenhongjie on 2018/12/20.
 */
public class URL implements Serializable{//因为map要存到文件中去,所以URL也要支持序列化
    private String hostname;
    private Integer port;

    public URL(String hostname, Integer port) {
        this.hostname = hostname;
        this.port = port;
    }

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    @Override
    //重写判断相同的方法,因为如果是2个URL对象，但是hostname，port一样的话，不重写equals的时候.hashmap(注册中心).get是get不到的,因为不同，重写equals就可以了，让host,port相同的url被认为是相同的
    public boolean equals(Object obj) {//重写equals的时候一定要重写hashcode
       // return super.equals(obj);
        URL url=(URL)obj;
        return Objects.equals(hostname,url.hostname)&&Objects.equals(port,url.port);
    }

    @Override
    public int hashCode() {
        //return super.hashCode();
        return Objects.hash(hostname,port);
    }
}
