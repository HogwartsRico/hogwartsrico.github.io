package org.rico.learnDubbo.framework;
import org.rico.learnDubbo.protocol.http.HttpClient;
import org.rico.learnDubbo.provider.api.HelloService;
import org.rico.learnDubbo.register.RegisterServer;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
/**
 * Created by chenhongjie on 2018/12/22.
 */
public class ProxyFactory<T> {
    //给某个接口生成代理类
    public static <T> T getProxy(final Class interfaceClass){
        //就用JDK的动态代理
        return (T) Proxy.newProxyInstance(interfaceClass.getClassLoader(), new Class[]{interfaceClass}, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                //没有invoke本地的sayHello实现方法,而是调用了远程的sayHello方法,然后拿到执行结果
                System.out.println("我是代理方法:开始调用远程方法");
                HttpClient httpClient=new HttpClient();
                TransferModel transferModel=new TransferModel(interfaceClass.getName(),method.getName(),args,new Class[]{String.class});//第一个参数:调用哪个接口 第二个参数:调用接口的哪个方法,第三个参数:参数组成的数组,第四个参数,参数类型数组
                //这个hostname和port要从注册中心去取,如果有多个服务都实现了这个方法，那就涉及到了负载均衡，看你取哪台集群了,有hsh,robin 这里只有1个实现了
                URL url = RegisterServer.random(interfaceClass.getName());//从注册中心获得我要去哪台服务器上去调用这个服务
                System.out.println("目标服务名:"+interfaceClass.getName());
                String result = httpClient.post(url.getHostname(),url.getPort(),transferModel);//使用post(http协议)去调用那台服务器的 方法，同时传给它方法名，接口名，参数,这个TransferModel是支持序列号的，可以传输,然后拿到服务提供方执行完成后返回的结果
                //System.out.println(result);
                System.out.println("我是代理方法:调用远程方法结束");
                return result;
            }
        });

    }


    /*
    newProxyInstance，方法有三个参数：
    loader: 用哪个类加载器去加载代理对象
    interfaces:动态代理类需要实现的接口
    h:动态代理方法在执行时，会调用h里面的invoke方法去执行
     */
}
