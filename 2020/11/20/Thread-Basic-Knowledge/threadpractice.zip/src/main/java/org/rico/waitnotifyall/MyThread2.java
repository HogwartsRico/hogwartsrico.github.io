package org.rico.waitnotifyall;

public class MyThread2 extends Thread{
    private Object lock;
    public MyThread2(Object lock) {
        this.lock = lock;
    }
    @Override
    public void run() {
        try {
            synchronized (lock) {
                System.out.println("thread2开始wait time:" + System.currentTimeMillis());
                lock.wait();
                System.out.println("thread2结束 time:" + System.currentTimeMillis());
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
