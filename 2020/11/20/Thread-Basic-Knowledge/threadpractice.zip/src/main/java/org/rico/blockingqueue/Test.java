package org.rico.blockingqueue;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Test {
    public static void main(String[] args) {
        final BlockingQueue<String> queue = new ArrayBlockingQueue<String>(10);
        Runnable producerRunnable = new Runnable() {
            int i = 0;
            public void run() {
                while (true) {
                    try {
                        i++;
                        System.out.println("我生产了一个" + i);
                        queue.put(i + "");
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        Thread producerThread = new Thread(producerRunnable);

        Thread customerThread = new Thread(()->{
            while (true) {
                try {
                    System.out.println("我消费了一个" + queue.take());
                    Thread.sleep(4000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        producerThread.start();
        customerThread.start();
    }
}
