package org.rico.login.serialize;

public interface SerializerAlogrithm {
    /**
     * json 序列化
     */
    byte JSON = 1;
}
