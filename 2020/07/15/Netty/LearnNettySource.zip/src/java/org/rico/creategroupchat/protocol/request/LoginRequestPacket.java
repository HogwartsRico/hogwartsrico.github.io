package org.rico.creategroupchat.protocol.request;

import lombok.Data;
import org.rico.creategroupchat.protocol.Packet;
import org.rico.creategroupchat.protocol.command.Command;

@Data
public class LoginRequestPacket extends Packet {
    private String userName;

    private String password;

    @Override
    public Byte getCommand() {
        return Command.LOGIN_REQUEST;
    }
}
