package org.rico.notifynotreleaselock;

public class Test {
    public static void main(String[] args) {
        Object lock = new Object();
        MyThread1 t1 = new MyThread1(lock);//调的是wait
        t1.start();
        MyThread2 t2 = new MyThread2(lock);//调的是notify
        t2.start();
        MyThread2 t2_ = new MyThread2(lock);//调的是notify,用2个线程来notify来证明，第一个notify是否释放了锁,如果释放了，第二个notify可以立即执行
        t2_.start();
    }
}
