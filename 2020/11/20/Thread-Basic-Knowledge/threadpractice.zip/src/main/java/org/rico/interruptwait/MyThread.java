package org.rico.interruptwait;

public class MyThread extends Thread{
    private Object lock;
    public MyThread(Object lock) {
        this.lock = lock;
    }
    public void run() {
        ThreadDomain td = new ThreadDomain();
        td.testMethod(lock);
    }
}
