package org.rico.pipline.server;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import org.rico.pipline.codec.PacketDecoder;
import org.rico.pipline.codec.PacketEncoder;
import org.rico.pipline.server.handler.LoginRequestHandler;
import org.rico.pipline.server.handler.MessageRequestHandler;
import java.util.Date;

public class NettyServer {

    private static final int PORT = 8000;

    public static void main(String[] args) {
        NioEventLoopGroup boosGroup = new NioEventLoopGroup();
        NioEventLoopGroup workerGroup = new NioEventLoopGroup();

        final ServerBootstrap serverBootstrap = new ServerBootstrap();
        serverBootstrap
                .group(boosGroup, workerGroup)
                .channel(NioServerSocketChannel.class)
                .option(ChannelOption.SO_BACKLOG, 1024)
                .childOption(ChannelOption.SO_KEEPALIVE, true)
                .childOption(ChannelOption.TCP_NODELAY, true)
                .childHandler(new ChannelInitializer<NioSocketChannel>() {
                    protected void initChannel(NioSocketChannel ch) {
                        //PacketDecoder继承了当我们继承了 ByteToMessageDecoder 这个类，可以实现解码
                        ch.pipeline().addLast(new PacketDecoder());//解码
                        //下面add的这些Handler都继承了 SimpleChannelInboundHandler
                        //SimpleChannelInboundHandler 从字面意思也可以看到，使用它非常简单，我们在继承这个类的时候，给他传递一个泛型参数，然后在 channelRead0() 方法里面，我们不用再通过 if 逻辑来判断当前对象是否是本 handler 可以处理的对象，也不用强转，不用往下传递本 handler 处理不了的对象，**这一切都已经交给父类 `SimpleChannelInboundHandler` 来实现了**，我们只需要专注于我们要处理的业务逻辑即可
                        ch.pipeline().addLast(new LoginRequestHandler());//登录请求
                        ch.pipeline().addLast(new MessageRequestHandler());//消息请求
                        //PacketEncyyoder继承了MessageToByteEncoder,它的功能就是将对象转换到二进制数据。
                        ch.pipeline().addLast(new PacketEncoder());//二进制
                    }
                });


        bind(serverBootstrap, PORT);
    }

    private static void bind(final ServerBootstrap serverBootstrap, final int port) {
        serverBootstrap.bind(port).addListener(future -> {
            if (future.isSuccess()) {
                System.out.println(new Date() + ": 端口[" + port + "]绑定成功!");
            } else {
                System.err.println("端口[" + port + "]绑定失败!");
            }
        });
    }
}
