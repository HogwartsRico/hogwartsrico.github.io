package org.rico.waitnotify;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        Object lock = new Object();
        MyThread1 t1 = new MyThread1(lock);
        t1.start();
        System.out.println("睡眠3秒后thread2进行notify");
        Thread.sleep(3000);
        MyThread2 t2 = new MyThread2(lock);
        t2.start();
    }
}
