package org.rico.reentrantreadwritelockdemo;

public class Test2 {
    public static void main(String[] args) throws InterruptedException {
        WriteService service = new WriteService();
        Thread a = new Thread(service::write);
        a.setName("A");
        Thread b = new Thread(service::write);
        b.setName("B");

        a.start();
        b.start();
        Thread.sleep(1000 * 30);
    }
}
