package org.rico.waitnotifyall;

public class NotifyThread extends Thread{
    private Object lock;
    public NotifyThread(Object lock) {
        this.lock = lock;
    }
    public void run() {
        synchronized (lock) {
            System.out.println("thread开始notify time:" + System.currentTimeMillis());
            lock.notifyAll();
            System.out.println("thread结束notify time:" + System.currentTimeMillis());
        }
    }
}
