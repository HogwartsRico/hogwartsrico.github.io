package org.rico.consumerproduceuselock;

import java.util.Queue;

public class Test {
    public static void main(String[] args) {
        final ThreadDomain td = new ThreadDomain();
        Thread ProducerThread = new Thread(()->{
            for (int i = 0; i < Integer.MAX_VALUE; i++){
                td.set();
            }
        });
        ProducerThread.setName("Producer");

        Thread ConsumerThread = new Thread(()->{
            for (int i = 0; i < Integer.MAX_VALUE; i++){
                td.get();
            }
        });
        ConsumerThread.setName("Consumer");

        ProducerThread.start();
        ConsumerThread.start();
    }
}
