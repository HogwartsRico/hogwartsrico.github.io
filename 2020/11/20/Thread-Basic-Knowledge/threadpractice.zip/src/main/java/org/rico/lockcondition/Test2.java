package org.rico.lockcondition;

public class Test2 {
    public static void main(String[] args) throws InterruptedException {
        ConditionAllService service = new ConditionAllService();
        Thread a = new Thread(service::awaitA);
        a.setName("A");
        a.start();
        Thread b = new Thread(service::awaitB);
        b.setName("B");
        b.start();
        Thread.sleep(1000 * 3);
        service.signAAll();
        Thread.sleep(1000 * 4);
        service.signBAll();
    }
}
