package org.rico.threadgroup;

public class Test {
    public static void main(String[] args) {
            Mythread mt0 = new Mythread();
            Mythread mt1 = new Mythread();
            ThreadGroup tg = new ThreadGroup("新建线程组1");
            Thread t0 = new Thread(tg, mt0);
            Thread t1 = new Thread(tg, mt1);
            t0.start();
            t1.start();
            System.out.println("活动的线程数为：" + tg.activeCount());
            System.out.println("线程组的名称为：" + tg.getName());
    }
}
