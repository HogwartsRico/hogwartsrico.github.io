package org.rico.currentThread;

public class MyThread extends Thread{
        public MyThread()    {
            System.out.println("开始执行构造函数");
            System.out.println("Thread.currentThread().getName():" + Thread.currentThread().getName());
            System.out.println("this.getName():" + this.getName());
            System.out.println("构造函数执行完毕");
        }

        public void run()    {
            System.out.println("run Begin");
            System.out.println("Thread.currentThread().getName():"+ Thread.currentThread().getName());
            System.out.println("this.getName():" + this.getName());
            System.out.println("run end");
        }
}
