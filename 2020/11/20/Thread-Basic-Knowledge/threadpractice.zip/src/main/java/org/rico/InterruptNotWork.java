package org.rico;

public class InterruptNotWork {
    public static void main(String[] args) {
            MyThread t = new MyThread();
            t.start();
            t.interrupt();
    }

    static class MyThread extends  Thread{
        @Override
        public void run() {
            for (int i = 0; i < 500000; i++) {
                System.out.println("i = " + (i + 1));
            }
        }
    }
}
