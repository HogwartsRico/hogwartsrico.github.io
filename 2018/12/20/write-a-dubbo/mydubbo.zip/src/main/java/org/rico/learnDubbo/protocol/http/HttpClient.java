package org.rico.learnDubbo.protocol.http;
import org.apache.commons.io.IOUtils;
import org.rico.learnDubbo.framework.TransferModel;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
/**
 * Created by chenhongjie on 2018/12/21.
 */
public class HttpClient {
    public String post(String hostname, Integer port, TransferModel transferModel) {
        try {
            //发送请求
            URL url = new URL("http", hostname, port, "/");
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(transferModel);
            objectOutputStream.flush();
            objectOutputStream.close();
            //发送完请求,然后拿到结果
            InputStream inputStream=httpURLConnection.getInputStream();
            return IOUtils.toString(inputStream);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return "";
        } catch (ProtocolException e) {
            e.printStackTrace();
            return "";
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }
}
