package org.rico.socket.stickup;

import java.io.*;
import java.net.Socket;

public class SocketClient {
    public static void main(String[] args) {
        try {
            Socket socket =new Socket("127.0.0.1",9999);
            for (int i = 0; i < 1000; i++) {
                socket.getOutputStream().write(new String("本小节我们来学习一下 Netty 里面拆包和粘包的概念，并且如何选择适合我们应用程序的拆包器").getBytes());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
