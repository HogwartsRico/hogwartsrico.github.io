package org.rico.singlechat.protocol.request;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.rico.singlechat.protocol.Packet;
import static org.rico.singlechat.protocol.command.Command.MESSAGE_REQUEST;

@Data
@NoArgsConstructor
public class MessageRequestPacket extends Packet {
    private String toUserId;//新增了这个
    private String message;

    public MessageRequestPacket(String toUserId, String message) {
        this.toUserId = toUserId;
        this.message = message;
    }

    @Override
    public Byte getCommand() {
        return MESSAGE_REQUEST;
    }
}
