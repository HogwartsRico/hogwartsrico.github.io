package org.rico.getqueuelength;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        final ThreadDomain td = new ThreadDomain();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                td.testMethod();
            }
        };
        Thread[] threads = new Thread[10];
        for (int i = 0; i < 10; i++){
            threads[i] = new Thread(runnable);
        }
        for (int i = 0; i < 10; i++){
            threads[i].start();
        }
        Thread.sleep(2000);
    }
}
