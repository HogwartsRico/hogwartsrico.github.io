package org.rico.learnDubbo.provider.api;

/**
 * Created by chenhongjie on 2018/12/20.
 */
public interface  HelloService {
    String sayHello(String username);
}
