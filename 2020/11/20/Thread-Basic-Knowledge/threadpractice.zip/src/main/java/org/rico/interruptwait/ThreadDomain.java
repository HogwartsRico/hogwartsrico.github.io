package org.rico.interruptwait;

public class ThreadDomain {
    public void testMethod(Object lock) {
        try {
            synchronized (lock) {
                System.out.println("开始wait");
                lock.wait();
                System.out.println("结束wait()");
            }
        } catch (InterruptedException e) {
            System.out.println("wait被interrupt()打断了！");
            e.printStackTrace();
        }
    }
}
