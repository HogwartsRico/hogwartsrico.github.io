package org.rico.learnDubbo.protocol.http;
import org.apache.commons.io.IOUtils;
import org.rico.learnDubbo.framework.TransferModel;
import org.rico.learnDubbo.framework.URL;
import org.rico.learnDubbo.register.RegisterServer;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
/**
 * Created by chenhongjie on 2018/12/20.
 */
public class HttpServerHandler{
    //处理请求和响应
    public void handler(HttpServletRequest req, HttpServletResponse resp){
        //对象通过网络传输
        InputStream inputStream = null;
        try {
            inputStream = req.getInputStream();
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            TransferModel  transferModel = (TransferModel)objectInputStream.readObject();//二进制数据反序列化成一个对象
            //根据transferModel中的信息去注册中心找接口的实现类
            String interfaceName = transferModel.getInterfaceName();
            URL url = new URL("localhost",8080);
            Class implementClass = RegisterServer.get(url,interfaceName);//根据url和接口名找一个实现类 该get方法通过读取之前注册服务的时候保存的javaobject文件复原成map,然后查询
            //然后new出这个实现类,然后执行一下需要调用的这个方法
            Method method = implementClass.getMethod(transferModel.getMethodName(),transferModel.getParamTypes());//这里Class的getMethod方法的第一个参数:方法的名字,第二个参数,方法的参数类型
            //执行,并保存返回值 注意这不是反射哦,也不是动态代理
            String result = (String)method.invoke(implementClass.newInstance(),transferModel.getParams());//第一个参数:new出来的这个实现类,第二个参数:参数 我们这里有位知道sayHello方法返回的是String，所以强转成String了,实际dubbo框架肯定是Object
            //然后把结果返回给调用方,通过outputstream返回给resp
            OutputStream outputStream = resp.getOutputStream();
            IOUtils.write(result,outputStream);//把字符串给output了 这样就完成了一个结果的返回
            //server端逻辑结束
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("找不到这个类");
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            System.out.println("没有这个方法");
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
