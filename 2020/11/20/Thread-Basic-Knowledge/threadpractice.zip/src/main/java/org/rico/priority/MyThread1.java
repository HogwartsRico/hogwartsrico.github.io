package org.rico.priority;

public class MyThread1 extends Thread{
    public void run() {
        long beginTime = System.currentTimeMillis();
        for (int j = 0; j < 100000; j++){}
        long endTime = System.currentTimeMillis();
        System.out.println("我是高优先级的 use time = " +   (endTime - beginTime));
    }
}
