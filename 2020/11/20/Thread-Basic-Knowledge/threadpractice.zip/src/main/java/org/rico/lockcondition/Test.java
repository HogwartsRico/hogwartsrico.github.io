package org.rico.lockcondition;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        ConditionWaitNotifyService service = new ConditionWaitNotifyService();
        new Thread(service::await).start();
        Thread.sleep(1000 * 3);
        System.out.println("singal的线程:"+Thread.currentThread().getName());
        service.signal();
        Thread.sleep(1000);
    }
}
