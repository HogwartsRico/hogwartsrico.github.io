package org.rico.login.protocol.request;

import lombok.Data;
import org.rico.login.protocol.Packet;
import static org.rico.login.protocol.command.Command.MESSAGE_REQUEST;
@Data
public class MessageRequestPacket extends Packet {

    private String message;

    @Override
    public Byte getCommand() {
        return MESSAGE_REQUEST;
    }
}
