package org.rico.pipline.protocol.response;

import lombok.Data;
import org.rico.pipline.protocol.Packet;
import static org.rico.login.protocol.command.Command.MESSAGE_RESPONSE;

@Data
public class MessageResponsePacket extends Packet {

    private String message;

    @Override
    public Byte getCommand() {

        return MESSAGE_RESPONSE;
    }
}
