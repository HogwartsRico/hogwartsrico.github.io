package org.rico.singlechat.serialize;

public interface SerializerAlogrithm {
    /**
     * json 序列化
     */
    byte JSON = 1;
}
