package org.rico.notifynotreleaselock;

public class MyThread2 extends Thread{
    private Object lock;

    public MyThread2(Object lock) {
        this.lock = lock;
    }

    public void run() {
        ThreadDomain td = new ThreadDomain();
        td.synNotifyMethod(lock);
    }
}
