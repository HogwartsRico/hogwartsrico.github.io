package org.rico;

public class InterruptDemo2 implements Runnable{
    private volatile static boolean flag = false;
    public static void main(String[] args) throws InterruptedException {
        Thread testThread = new Thread(new InterruptDemo2(),"InterruptionInJava");
        testThread.start();
        Thread.sleep(1000);
        InterruptDemo2.flag = true;
        System.out.println("主线程结束");
    }
    @Override
    public void run() {
        while(!flag){
            System.out.println("---");
        }
    }
}
