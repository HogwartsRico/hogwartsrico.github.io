package org.rico.getholdcount;

public class Test {
    public static void main(String[] args) {
        ThreadDomain td = new ThreadDomain();
        td.testMethod1();
    }
}
