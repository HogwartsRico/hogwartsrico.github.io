package org.rico.learnDubbo.framework;
import java.io.Serializable;
/**
 * 这个对象需要在网络中进行传输,所以需要能够被序列化
 * Created by chenhongjie on 2018/12/21.
 */
public class TransferModel implements Serializable{
    private String interfaceName;//接口名
    private String methodName;//方法名
    private Object[] params;//参数
    private  Class[] paramTypes;//参数类型

    public TransferModel(String interfaceName, String methodName, Object[] params, Class[] paramTypes) {
        this.interfaceName = interfaceName;
        this.methodName = methodName;
        this.params = params;
        this.paramTypes = paramTypes;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public Object[] getParams() {
        return params;
    }

    public void setParams(Object[] params) {
        this.params = params;
    }

    public Class[] getParamTypes() {
        return paramTypes;
    }

    public void setParamTypes(Class[] paramTypes) {
        this.paramTypes = paramTypes;
    }
}
