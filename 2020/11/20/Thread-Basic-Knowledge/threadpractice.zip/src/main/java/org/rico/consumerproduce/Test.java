package org.rico.consumerproduce;

public class Test {
    public static void main(String[] args) {
        Object lock = new Object();
        final Producer producer = new Producer(lock);
        final Customer customer = new Customer(lock);
        Thread producerThread = new Thread(()->{
            while ((true)) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                producer.setValue();
            }
        });
        Thread CustomerThread = new Thread(()->{
            while (true) {
                customer.getValue();
            }
        });
        producerThread.start();
        CustomerThread.start();
    }
}
