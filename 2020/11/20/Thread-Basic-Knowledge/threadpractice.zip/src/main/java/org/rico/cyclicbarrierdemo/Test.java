package org.rico.cyclicbarrierdemo;

import java.util.concurrent.CyclicBarrier;

public class Test {
    public static void main(String[] args) {
        CyclicBarrier cyclicBarrier = new CyclicBarrier(3, ()->{
            System.out.println("CyclicBarrier的所有线程await()结束了，我运行了, 时间为" + System.currentTimeMillis());
        });
        CyclicBarrierThread cbt0 = new CyclicBarrierThread(cyclicBarrier, 3);
        CyclicBarrierThread cbt1 = new CyclicBarrierThread(cyclicBarrier, 6);
        CyclicBarrierThread cbt2 = new CyclicBarrierThread(cyclicBarrier, 9);
        cbt0.start();
        cbt1.start();
        cbt2.start();
    }
}
