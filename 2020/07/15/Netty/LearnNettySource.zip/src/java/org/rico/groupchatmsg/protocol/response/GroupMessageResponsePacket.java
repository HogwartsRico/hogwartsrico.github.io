package org.rico.groupchatmsg.protocol.response;

import lombok.Data;
import org.rico.groupchatmsg.protocol.Packet;
import org.rico.groupchatmsg.protocol.command.Command;
import org.rico.groupchatmsg.session.Session;

@Data
public class GroupMessageResponsePacket extends Packet {

    private String fromGroupId;

    private Session fromUser;

    private String message;

    @Override
    public Byte getCommand() {

        return Command.GROUP_MESSAGE_RESPONSE;
    }
}
