package org.rico.fairlock;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ThreadDomain {
    private Lock lock = new ReentrantLock(false);
    public void testMethod() {
        try {
            lock.lock();
            System.out.println("ThreadName" + Thread.currentThread().getName() + "获得锁");
        } finally {
            lock.unlock();
        }
    }
}
