package org.example;

public class Constants {
    public static final String HOST = "172.28.65.183";
    public static final Integer PORT = 6379;
}
