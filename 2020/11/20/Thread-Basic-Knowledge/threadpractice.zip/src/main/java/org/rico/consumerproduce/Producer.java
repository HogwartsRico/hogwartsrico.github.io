package org.rico.consumerproduce;

public class Producer {
    private Object lock;
    public Producer(Object lock) {
        this.lock = lock;
    }
    public void setValue() {
        try {
            synchronized (lock) {
                if (!ValueObject.value.equals("")) {
                    lock.wait();//缓冲区有东西，消费者没来得及消费，就暂停生产
                }
                String value = System.currentTimeMillis() + "_" + System.nanoTime();
                System.out.println("Set的值是：" + value);
                ValueObject.value = value;
                lock.notify();//生产了，通知消费者消费
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
