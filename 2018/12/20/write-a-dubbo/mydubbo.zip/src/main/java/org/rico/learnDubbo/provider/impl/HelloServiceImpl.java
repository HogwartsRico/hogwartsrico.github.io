package org.rico.learnDubbo.provider.impl;

import org.rico.learnDubbo.provider.api.HelloService;

/**
 * Created by chenhongjie on 2018/12/20.
 */
public class HelloServiceImpl implements HelloService{

    @Override
    public String sayHello(String username) {
        return "Hello,"+username+"!";
    }
}
