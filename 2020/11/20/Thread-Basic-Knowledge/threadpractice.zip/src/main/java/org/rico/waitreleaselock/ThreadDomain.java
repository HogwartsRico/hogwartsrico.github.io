package org.rico.waitreleaselock;

public class ThreadDomain {
    public void testMethod(Object lock) {
        try {
            synchronized (lock) {
                System.out.println(Thread.currentThread().getName() + "开始wait");
                lock.wait();
                System.out.println(Thread.currentThread().getName() + "结束wait");
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
