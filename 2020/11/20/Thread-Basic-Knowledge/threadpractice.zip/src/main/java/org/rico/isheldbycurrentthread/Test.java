package org.rico.isheldbycurrentthread;

public class Test {
    public static void main(String[] args) {
        final ThreadDomain td = new ThreadDomain();
        Thread t0 = new Thread(()->td.testMethod());
        Thread t1 = new Thread(()->td.testHoldLock());
        System.out.println("thread0启动");
        t0.start();
        System.out.println("thread1启动");
        t1.start();
    }
}
