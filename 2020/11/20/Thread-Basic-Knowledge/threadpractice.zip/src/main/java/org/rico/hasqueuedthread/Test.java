package org.rico.hasqueuedthread;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        final ThreadDomain td = new ThreadDomain();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                td.waitMethod();
            }
        };
        Thread t0 = new Thread(runnable); t0.start();
        Thread t1 = new Thread(runnable); t1.start();
        Thread t2 = new Thread(runnable); t2.start();

        System.out.println("t0是否正在等待 ？" + td.hasQueuedThread(t0));
        System.out.println("t1是否正在等待？" + td.hasQueuedThread(t1));
        System.out.println("t2是否正在等待？" + td.hasQueuedThread(t2));
        System.out.println("is any thread waiting？" + td.hasQueuedThreads());
    }
}
