package org.rico.groupchatmsg.serialize;

public interface SerializerAlgorithm {
    /**
     * json 序列化
     */
    byte JSON = 1;
}
