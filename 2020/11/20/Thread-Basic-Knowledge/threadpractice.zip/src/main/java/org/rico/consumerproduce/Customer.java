package org.rico.consumerproduce;

public class Customer {
    private Object lock;
    public Customer(Object lock) {
        this.lock = lock;
    }
    public void getValue() {
        try {
            synchronized (lock) {
                if (ValueObject.value.equals("")){
                    lock.wait();//队列中没有东西,等待
                }
                System.out.println("Get的值是：" + ValueObject.value);
                ValueObject.value = "";
                lock.notify();//消费了,通知生产者生产
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
