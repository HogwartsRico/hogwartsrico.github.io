#!/bin/bash

# Run namesrv and broker on your Kubernetes cluster
kubectl create -f kubernetes/deployment.yaml