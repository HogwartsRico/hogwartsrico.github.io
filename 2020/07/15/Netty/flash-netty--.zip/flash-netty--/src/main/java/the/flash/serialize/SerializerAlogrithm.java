package the.flash.serialize;

public interface SerializerAlogrithm {
    /**
     * json 序列化
     */
    byte JSON = 1;
}
