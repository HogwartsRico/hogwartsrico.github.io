package org.rico.groupchatmsg.protocol.response;

import lombok.Data;
import org.rico.groupchatmsg.protocol.Packet;
import org.rico.groupchatmsg.protocol.command.Command;

@Data
public class LoginResponsePacket extends Packet {
    private String userId;

    private String userName;

    private boolean success;

    private String reason;


    @Override
    public Byte getCommand() {

        return Command.LOGIN_RESPONSE;
    }
}
