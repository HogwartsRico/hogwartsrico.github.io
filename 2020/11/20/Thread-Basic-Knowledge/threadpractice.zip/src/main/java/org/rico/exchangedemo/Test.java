package org.rico.exchangedemo;

import java.util.concurrent.Exchanger;

public class Test {
    public static void main(String[] args) {
        Exchanger<String> exchanger = new Exchanger<String>();
        ExchangerThread et0 = new ExchangerThread("111", exchanger, 5);
        ExchangerThread et1 = new ExchangerThread("222", exchanger, 2);
        et0.start();
        et1.start();
    }
}
