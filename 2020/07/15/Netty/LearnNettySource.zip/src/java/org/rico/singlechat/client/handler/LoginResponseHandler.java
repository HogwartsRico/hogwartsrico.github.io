package org.rico.singlechat.client.handler;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import org.rico.singlechat.attribute.Attributes;
import org.rico.singlechat.protocol.response.LoginResponsePacket;
import org.rico.singlechat.session.Session;
import org.rico.singlechat.util.SessionUtil;

public class LoginResponseHandler extends SimpleChannelInboundHandler<LoginResponsePacket> {

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, LoginResponsePacket loginResponsePacket) {
        String userId = loginResponsePacket.getUserId();
        String userName = loginResponsePacket.getUserName();

        if (loginResponsePacket.isSuccess()) {
            System.out.println("[" + userName + "]登录成功，userId 为: " + loginResponsePacket.getUserId());
            //SessionUtil.bindSession(new Session(userId, userName), ctx.channel());//其实这里的作用就是为了给channel设置登录标记,而不是绑定channel与userid的映射关系,为了避免引起误解，注掉了。 改为下面的
            ctx.channel().attr(Attributes.SESSION).set(new Session(userId, userName));//channel设置登录标记
        } else {
            System.out.println("[" + userName + "]登录失败，原因：" + loginResponsePacket.getReason());
        }
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) {
        System.out.println("客户端连接被关闭!");
    }
}
