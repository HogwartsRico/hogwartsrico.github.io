package the.flash.protocol.command;

public interface Command {

    Byte LOGIN_REQUEST = 1;
}
