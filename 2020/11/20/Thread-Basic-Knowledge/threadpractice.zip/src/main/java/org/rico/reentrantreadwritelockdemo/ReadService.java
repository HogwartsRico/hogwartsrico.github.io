package org.rico.reentrantreadwritelockdemo;

import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ReadService {
    private ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    public void read(){
        try{
            try{
                lock.readLock().lock();
                System.out.println("获得读锁" + Thread.currentThread().getName() + " " + System.currentTimeMillis());
                Thread.sleep(1000 * 10);
            }finally {
                System.out.println("释放读锁");
                lock.readLock().unlock();
            }
        }catch (InterruptedException e){
            e.printStackTrace();
        }
    }
}
