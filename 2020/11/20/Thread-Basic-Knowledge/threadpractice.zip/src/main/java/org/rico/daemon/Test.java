package org.rico.daemon;

public class Test {
    public static void main(String[] args) {
        try {
            MyThread mt = new MyThread();
            mt.setDaemon(true);
            mt.start();
            Thread.sleep(5000);
            System.out.println("我离开非守护线程就停止执行了，再也不打印了！");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
