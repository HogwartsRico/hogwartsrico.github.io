package org.rico.waitnotifyall;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        Object lock = new Object();
        MyThread1 t1 = new MyThread1(lock);
        MyThread2 t2 = new MyThread2(lock);
        t1.start();
        t2.start();
        System.out.println("睡眠3秒后");
        Thread.sleep(3000);
        NotifyThread nt  = new NotifyThread(lock);
        nt.start();
    }
}
