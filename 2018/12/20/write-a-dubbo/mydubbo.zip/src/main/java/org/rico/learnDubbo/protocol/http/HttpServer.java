package org.rico.learnDubbo.protocol.http;

import org.apache.catalina.*;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.core.StandardContext;
import org.apache.catalina.core.StandardEngine;
import org.apache.catalina.core.StandardHost;
import org.apache.catalina.startup.Tomcat;

/**
 * Created by chenhongjie on 2018/12/20.
 */
public class HttpServer {
    public void start(String hostname,Integer port){
        Tomcat tomcat=new Tomcat();

        Server server=tomcat.getServer();
        Service service=server.findService("Tomcat");//默认 叫tomcat

        Connector connector=new Connector();
        connector.setPort(port);

        Engine engine=new StandardEngine();
        engine.setDefaultHost(hostname);

        Host host=new StandardHost();
        host.setName(hostname);

        String contextPath="";
        Context context=new StandardContext();
        context.setPath(contextPath);
        context.addLifecycleListener(new Tomcat.FixContextListener());//加一个tomcat生命周期的监听器

        host.addChild(context);
        engine.addChild(host);

        service.setContainer(engine);
        service.addConnector(connector);
        //tomcat是servlet的容器 所以要加入servlet,servlet用来处理请求的
        tomcat.addServlet(contextPath,"dispatcher",new DispatcherServlet());//指定servlet,第二个参数是servlet的名字，第三个参数是指定其实现类
        context.addServletMappingDecoded("/*","dispatcher");//mapping
        try {
            tomcat.start();//只是初始化
            tomcat.getServer().await();//接收请求
        } catch (LifecycleException e) {
            e.printStackTrace();
        }
    }
}
