package org.rico.reentrantreadwritelockdemo;

public class Test3 {
    public static void main(String[] args) throws InterruptedException {
        WriteReadService service = new WriteReadService();
        Thread a = new Thread(service::write);
        a.setName("A");
        a.start();
        //Thread.sleep(1000);

        Thread b = new Thread(service::read);
        b.setName("B");
        b.start();

        Thread.sleep(1000 * 30);
    }
}
