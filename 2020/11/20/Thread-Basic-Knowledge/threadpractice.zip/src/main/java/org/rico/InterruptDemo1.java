package org.rico;

public class InterruptDemo1 implements Runnable{
    public static void main(String[] args) throws InterruptedException {
        Thread testThread = new Thread(new InterruptDemo1(),"InterruptionInJava");
        testThread.start();
        Thread.sleep(1000);
        testThread.interrupt();
        System.out.println("主线程结束");
    }
    @Override
    public void run() {
        while(true){
            if(Thread.currentThread().isInterrupted()){
                System.out.println("我被打断了，但我仍然在运行");

            }else{
                System.out.println("还没被打断");
            }
        }
    }
}
