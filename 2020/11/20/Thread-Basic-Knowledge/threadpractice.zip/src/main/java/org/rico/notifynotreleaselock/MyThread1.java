package org.rico.notifynotreleaselock;

public class MyThread1 extends Thread{
    private Object lock;

    public MyThread1(Object lock) {
        this.lock = lock;
    }

    public void run() {
        ThreadDomain td = new ThreadDomain();
        td.testMethod(lock);
    }
}
