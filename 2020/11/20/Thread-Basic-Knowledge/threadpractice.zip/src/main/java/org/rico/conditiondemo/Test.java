package org.rico.conditiondemo;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        ConditionWaitNotifyService service = new ConditionWaitNotifyService();
        new Thread(service::await).start();
        Thread.sleep(1000 * 3);
        service.signal();
        Thread.sleep(1000);
    }
}
