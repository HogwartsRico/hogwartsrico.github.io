package org.rico.singlechat.attribute;

import io.netty.util.AttributeKey;
import org.rico.singlechat.session.Session;

public interface Attributes {
    AttributeKey<Session> SESSION = AttributeKey.newInstance("session");
}
