package org.rico.groupchatmsg.attribute;

import io.netty.util.AttributeKey;
import org.rico.groupchatmsg.session.Session;

public interface Attributes {
    AttributeKey<Session> SESSION = AttributeKey.newInstance("session");
}
