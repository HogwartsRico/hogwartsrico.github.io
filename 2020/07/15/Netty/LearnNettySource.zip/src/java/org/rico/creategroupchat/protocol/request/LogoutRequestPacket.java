package org.rico.creategroupchat.protocol.request;

import lombok.Data;
import org.rico.creategroupchat.protocol.Packet;
import org.rico.creategroupchat.protocol.command.Command;

@Data
public class LogoutRequestPacket extends Packet {
    @Override
    public Byte getCommand() {

        return Command.LOGOUT_REQUEST;
    }
}
