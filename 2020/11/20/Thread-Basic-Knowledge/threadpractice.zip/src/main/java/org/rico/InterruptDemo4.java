package org.rico;

public class InterruptDemo4 implements Runnable {
    private volatile static boolean flag = false;
    public static void main(String[] args) throws InterruptedException {
        Thread testThread = new Thread(new InterruptDemo4(),"InterruptionInJava");
        testThread.start();
        Thread.sleep(1000);
        InterruptDemo4.flag = true;
        testThread.interrupt();
        System.out.println("打断");
        System.out.println("主线程结束");
    }

    @Override
    public void run() {
        while(!flag){
            try {
                System.out.println("没中断,睡上10000秒");
                Thread.sleep(10000000);
            } catch (InterruptedException e) {
                System.out.println("捕捉到异常: "+e);
            }
        }
    }

}
