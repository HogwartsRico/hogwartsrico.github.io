package org.rico.interruptwait;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        Object lock = new Object();
        MyThread mt = new MyThread(lock);
        mt.start();
        Thread.sleep(5000);
        mt.interrupt();
    }
}
