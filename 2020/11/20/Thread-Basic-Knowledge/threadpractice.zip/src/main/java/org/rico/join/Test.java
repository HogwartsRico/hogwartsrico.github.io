package org.rico.join;

public class Test {
    public static void main(String[] args) throws InterruptedException {
        MyThread mt = new MyThread();
        mt.start();
        mt.join();
        System.out.println("我想等别人执行完毕之后我再执行，我做到了");
    }
}
