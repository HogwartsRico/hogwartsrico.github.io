package org.rico.pipline.codec;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.rico.pipline.protocol.PacketCodeC;
import java.util.List;

public class PacketDecoder extends ByteToMessageDecoder {

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List out) {
        //in传递进来的时候就已经是 ByteBuf 类型，所以我们不再需要强转，第三个参数是List类型，我们通过往这个List里面添加解码后的结果对象，就可以自动实现结果往下一个 handler 进行传递**，这样，我们就实现了解码的逻辑 handler。
        out.add(PacketCodeC.INSTANCE.decode(in));//decode return的是Packet类型,下面的LoginRequestHandler能直接用
    }
}
